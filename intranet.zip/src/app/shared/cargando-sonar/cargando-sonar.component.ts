import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cargando-sonar',
  templateUrl: './cargando-sonar.component.html',
  styleUrls: ['./cargando-sonar.component.css']
})
export class CargandoSonarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
