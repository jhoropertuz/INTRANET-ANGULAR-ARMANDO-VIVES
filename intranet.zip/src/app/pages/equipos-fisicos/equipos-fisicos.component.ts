import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-equipos-fisicos',
  templateUrl: './equipos-fisicos.component.html',
  styleUrls: ['./equipos-fisicos.component.css']
})
export class EquiposFisicosComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
