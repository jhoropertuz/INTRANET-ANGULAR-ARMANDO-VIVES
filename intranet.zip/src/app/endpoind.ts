export const Endpoind={
  API_BASE:"https://intranet.hujmb.com/api/",
  ARCHIVOS:"https://intranet.hujmb.com/api/INTRANET_ARCHIVOS/"
}

